import 'package:flutter/material.dart';

class AuditPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<AuditPage> {
  @override
  Widget build(BuildContext context) {
    return layout(context);
  }

  Widget layout(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        elevation: 0.2,
        centerTitle: true,
        iconTheme: IconThemeData(),
        title: new Text(
          '审批',
          textAlign:TextAlign.center,
          style: TextStyle(
            color: Color(0xff333333),
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: <Widget>[
          IconButton(
              icon: Icon(
                  Icons.more_horiz,
                  color: Color(0xff333333)
              ),
              onPressed: null
          )
        ],
        backgroundColor: Colors.white,
      ),
      body: new ListView(
        children: <Widget>[

        ],
      ),
    );
  }
}

