import 'package:flutter/material.dart';

class PersonalPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new Page();
  }
}

class Page extends State<PersonalPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xfff7f7f7),
        body: new SingleChildScrollView(
          child: Column(
            children: <Widget>[

            ],
          ),
        )
    );
  }
}

